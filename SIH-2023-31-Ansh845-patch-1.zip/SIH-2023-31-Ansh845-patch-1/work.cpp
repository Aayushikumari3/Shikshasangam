#include <bits/stdc++.h>
using namespace std;

int st[10];
int top=-1;

int main(){


    return 0;
}