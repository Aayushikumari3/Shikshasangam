# SIH-2023-31
SIH 2023 team 31
# Team Members
1. Soumya Goel
2. Aayushi Kumari
3. Soumya Ranjan
4. Utkarsh
5. Kchitiz
6. Ansh Shrivashtav
